-- phpMyAdmin SQL Dump
-- version 2.11.3
-- http://www.phpmyadmin.net
--
-- Servidor: mysql.webcindario.com
-- Tiempo de generaci�n: 15-12-2009 a las 21:55:34
-- Versi�n del servidor: 5.0.22
-- Versi�n de PHP: 5.2.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Base de datos: `xam`
--
CREATE DATABASE `xam` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `xam`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `username` varchar(30) NOT NULL,
  `nombre` varchar(30) default NULL,
  `contrase�a` varchar(300) default NULL,
  PRIMARY KEY  (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`username`, `nombre`, `contrase�a`) VALUES
('biper', 'Biper Asus', 'bip321'),
('marco', 'Marco Andres', '123213');