<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>REGISTRO DE USUARIOS</title>
<script type="text/javascript" language="javascript" src="ajax.js"></script>
<style type="text/css">
<!--
#sam {
	position:absolute;
	left:240px;
	top:134px;
	width:434px;
	height:177px;
	z-index:1;
	border:thin;
	border-style:outset;
	padding:15px;
}
.style1 {
	font-family: Calibri;
	font-weight: bold;
	color: #999999;

}
.style4 {
	font-family: Calibri;
	font-weight: bold;
	color: #333333;
	font-size:11px;
}
.ok{
	background-color:#99FF99;
	font-family: Calibri;
	font-weight: bold;
	color: #999999;
	font-size:12px;
}
.error{
	background-color:#FFAAAA;
	font-family: Calibri;
	font-weight: bold;
	color: #999999;
	font-size:12px;
}



.style8 {font-family: Calibri; color: #535353; }
-->
</style>
</head>
<body>

<div id="sam">
 <div align="center" class="style1">REGISTRO DE USUARIO</div><br/>
   <div id="estadoUser"></div>
  <form id="formUsuario" name="formUsuario" method="post">
    <table width="100%" border="0">
      <tr>
        <td><span class="style8">Username:</span></td>
        <td><input type="text" name="txt_username" id="txt_username" />
        <input name="button" type="button" class="style4" id="button" value="Disponible?" onclick="javascript:ComprobarUsuario('./comprobarUser.php','estadoUser')" /></td>
      </tr>
      <tr>
        <td><span class="style8">Nombre:</span></td>
        <td><input type="text" name="textfield2" id="textfield2" /></td>
      </tr>
      <tr>
        <td><span class="style8">Password:</span></td>
        <td><input type="password" name="textfield3" id="textfield3" /></td>
      </tr>
    </table>
    <div align="center">
      <input name="" type="button" value="ENVIAR" />
      </div>
  </form>
 

</div>
</body>
</html>
